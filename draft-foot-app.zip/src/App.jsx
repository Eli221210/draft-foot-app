import React, { useState } from "react";
import { PlayerCard } from "./components/PlayerCard";
import { DraftBoard } from "./components/DraftBoard";

const App = () => {
  const [draftStep, setDraftStep] = useState(0);
  const [teamA, setTeamA] = useState([]);
  const [teamB, setTeamB] = useState([]);
  const [currentTeam, setCurrentTeam] = useState("A");
  const [budget, setBudget] = useState(100);

  const playersMock = [
    {
      id: 1,
      name: "Kylian Mbappé",
      position: "ATT",
      value: 30,
      note: 8.5,
      stats: { speed: 95, shot: 92, pass: 85, dribble: 93, def: 40, phy: 80 },
    },
    {
      id: 2,
      name: "Kevin De Bruyne",
      position: "MID",
      value: 25,
      note: 8.8,
      stats: { speed: 78, shot: 85, pass: 95, dribble: 88, def: 70, phy: 75 },
    }
  ];

  const handlePick = (player) => {
    if (currentTeam === "A" && budget - player.value >= 0) {
      setTeamA([...teamA, player]);
      setCurrentTeam("B");
    } else if (currentTeam === "B" && budget - player.value >= 0) {
      setTeamB([...teamB, player]);
      setCurrentTeam("A");
    }
    setBudget(budget - player.value);
    setDraftStep(draftStep + 1);
  };

  const calcScore = (team) => {
    if (team.length === 0) return 0;
    const total = team.reduce((acc, p) => acc + p.note, 0);
    return (total / team.length).toFixed(2);
  };

  return (
    <div className="p-4 text-center">
      <h1 className="text-2xl font-bold mb-4">Draft Football 1v1</h1>
      <p className="mb-2">Équipe A: {calcScore(teamA)} | Équipe B: {calcScore(teamB)}</p>
      <p className="mb-4">Budget restant: {budget}M€</p>
      <div className="grid grid-cols-2 gap-4">
        {playersMock.map((player) => (
          <PlayerCard key={player.id} player={player} onPick={handlePick} />
        ))}
      </div>
      <div className="mt-6">
        <DraftBoard teamA={teamA} teamB={teamB} />
      </div>
    </div>
  );
};

export default App;