import React from "react";

export const DraftBoard = ({ teamA, teamB }) => {
  return (
    <div className="mt-4">
      <h3 className="text-xl font-semibold mb-2">Compositions</h3>
      <div className="flex justify-around">
        <div>
          <h4 className="font-bold">Équipe A</h4>
          {teamA.map((p, i) => <p key={i}>{p.name}</p>)}
        </div>
        <div>
          <h4 className="font-bold">Équipe B</h4>
          {teamB.map((p, i) => <p key={i}>{p.name}</p>)}
        </div>
      </div>
    </div>
  );
};