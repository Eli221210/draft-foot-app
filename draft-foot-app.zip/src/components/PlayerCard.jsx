import React from "react";

export const PlayerCard = ({ player, onPick }) => {
  return (
    <div className="border p-2 rounded shadow text-left hover:bg-gray-100 cursor-pointer" onClick={() => onPick(player)}>
      <h2 className="font-bold">{player.name}</h2>
      <p>Position: {player.position}</p>
      <p>Valeur: {player.value}M€</p>
      <p>Note: {player.note}</p>
      <div className="text-sm mt-2">
        <p>Stats: VIT {player.stats.speed} | TIR {player.stats.shot} | PAS {player.stats.pass}</p>
      </div>
    </div>
  );
};